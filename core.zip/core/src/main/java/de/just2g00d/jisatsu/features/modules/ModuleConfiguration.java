package de.just2g00d.jisatsu.features.modules;

import de.just2g00d.jisatsu.manager.ManagerConfiguration;

public class ModuleConfiguration extends ManagerConfiguration {

  public ModuleConfiguration() {
    super(ModuleManager.class);
  }
}
