package de.just2g00d.jisatsu.features.modules.utils;

public enum ModuleCategory {

    SERVERHELPER, FPS, LISTENERS
}
