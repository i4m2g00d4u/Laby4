package de.just2g00d.jisatsu.versioned;

import net.labymod.api.reference.annotation.Referenceable;

@Referenceable
public interface MinecraftVersionController {

  void onJump();

}
