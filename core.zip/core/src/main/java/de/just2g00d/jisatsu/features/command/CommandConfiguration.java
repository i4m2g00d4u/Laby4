package de.just2g00d.jisatsu.features.command;

import de.just2g00d.jisatsu.manager.ManagerConfiguration;

public class CommandConfiguration extends ManagerConfiguration {

  public CommandConfiguration() {
    super(CommandManager.class);
  }

}
