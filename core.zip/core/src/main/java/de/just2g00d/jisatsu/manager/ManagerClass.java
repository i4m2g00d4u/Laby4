package de.just2g00d.jisatsu.manager;

public interface ManagerClass {

  public void onEnable();

  public void onDisable();

}
